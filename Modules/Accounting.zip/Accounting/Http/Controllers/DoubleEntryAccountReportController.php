<?php

namespace Modules\Accounting\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Accounting\Entities\DoubleEntryAccount;

class DoubleEntryAccountReportController extends Controller
{
    public function trialBalance()
    {   

        $table_data =   $this->getTrialBalanceData(date('Y-m-d'));
       // return $table_data;
        return view('accounting::reports.trial_balance',compact('table_data'));
 
    }

    public function trialBalanceData(Request $request)
    {   
        
        //return $request->all();
         
        $rp_date = date('Y-m-d',strtotime($request->rp_date));
         return $this->getTrialBalanceData($rp_date);
    }

    public function getTrialBalanceData($date_of_report=null)
    {   
        //return $date_of_report;
            $accounts_data = DoubleEntryAccount::where('acc_accounts.is_active',1)
                        ->join('acc_account_types as AT','AT.id','=','acc_accounts.account_type_id')
                        ->join('acc_account_categories as AC','AC.id','=','acc_accounts.category_id');

                        if($date_of_report==null){
                            $accounts_data->select(['acc_accounts.*','AT.type','AT.id as tr_type_id','AT.trs_type','AC.category_name','AC.category_code',
                                DB::raw('(SELECT SUM(IF(ALE.entry_type=IF((tr_type_id <= 2), "DR", "CR"), ALE.amount, -1 * ALE.amount)) FROM acc_ledger_transactions AS ALE 
                                INNER JOIN acc_transactions AS ATS ON ALE.transaction_id = ATS.id WHERE ALE.account_id = acc_accounts.id 
                                AND ATS.is_canceled=0 ) as account_balance')]
                            );
                        }else{
                            $accounts_data->select(['acc_accounts.*','AT.type','AT.id as tr_type_id' ,'AT.trs_type','AC.category_name','AC.category_code',
                                DB::raw('(SELECT SUM(IF(ALE.entry_type=IF((tr_type_id <= 2), "DR", "CR"), ALE.amount, -1 * ALE.amount)) FROM acc_ledger_transactions AS ALE 
                                INNER JOIN acc_transactions AS ATS ON ALE.transaction_id = ATS.id WHERE ATS.transaction_date <= "'.$date_of_report.'" AND ALE.account_id = acc_accounts.id 
                                AND ATS.is_canceled=0 ) as account_balance')]
                            );
                        }
                        
                        // ->groupBy('acc_accounts.account_type_id','acc_accounts.category_id')   
                     $accounts_all = $accounts_data->orderBy('account_code','ASC')
                                    ->orderBy('AT.id','ASC')
                                    ->get();
                
           // dd($accounts);
           $accounts_all = $accounts_all->groupBy('type');
        //    $accounts_all = $accounts_all->groupBy('category_name');  
            // return $accounts_all;
        $table_html='';

        $total_debit =0;
        $total_credit =0;


           foreach($accounts_all as $type => $accounts){

                 $accounts = $accounts->groupBy('category_name');
                 $table_html .='<tr class="acc-type">
                                    <th colspan="6">'.strtoupper($type).'</th>
                                </tr> ';
                 foreach($accounts as $category => $account){
                        $table_html .='<tr class="acc-category">
                                            <td colspan="1" class="text-center"> - </td>
                                            <th colspan="5">* <i>'.$category.'</i></th>
                                        </tr>';

                      foreach($account as $acc){
                        $table_html .='<tr>
                                            <td colspan="2"></td>
                                            <td>'.$acc->account_code.'</td>
                                            <td>'.$acc->account_name.' - ('.$acc->account_no.')</td>
                                            <td class="text-right"><b>'.((($acc->trs_type=='DEBIT') ? number_format($acc->account_balance,2,'.',',') : null)).'</b></td>
                                            <td class="text-right"><b>'.((($acc->trs_type=='CREDIT') ? number_format($acc->account_balance,2,'.',',') : null)).'</b></td>
                                        </tr>';
                        $total_debit +=((($acc->trs_type=='DEBIT') ? number_format($acc->account_balance,2,'.','') : 0));
                        $total_credit +=((($acc->trs_type=='CREDIT') ? number_format($acc->account_balance,2,'.','') : 0));
                      }
                 }
           }

           $table_html .='<tr class="bg-danger balance">
                            <th colspan="4" class="text-right"><h4 class="bold-font">BALANCE :</h4></th>
                            <th class="text-right"><h4 class="bold-font">'.number_format($total_debit,2,'.',',').'</h4></th>
                            <th class="text-right"><h4 class="bold-font">'.number_format($total_credit,2,'.',',').'</h4></th>
                        </tr>';

            return $table_html;
            
    }
}
