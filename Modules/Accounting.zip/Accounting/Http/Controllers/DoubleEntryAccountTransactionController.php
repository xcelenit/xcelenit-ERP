<?php

namespace Modules\Accounting\Http\Controllers;

use App\User;
use App\Contact;
use App\BusinessLocation;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Utils\TransactionUtil;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;
use Modules\Accounting\Entities\Utility\Utility;
use Modules\Accounting\Entities\DoubleEntryAccount;
use Modules\Accounting\Entities\DoubleEntryTransaction;
use Modules\Accounting\Entities\Utility\AccountUtility;
use Modules\Accounting\Entities\Utility\AccountTransactionUtility;

class DoubleEntryAccountTransactionController extends Controller
{
    protected $accountUtility;
    protected $utility;
    protected $accountTransactionutility;
    protected $transactionUtil;


    public function __construct(Utility $utility, AccountUtility $accountUtility,TransactionUtil $transactionUtil,AccountTransactionUtility $accountTransactionutility) {
        $this->utility = $utility;
        $this->accountUtility = $accountUtility;
        $this->transactionUtil = $transactionUtil;
        $this->accountTransactionutility = $accountTransactionutility;

    }  
    
    public function index()
     {  
        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id, false);
        $vendors = $this->utility->vendorDropdown($business_id, true);
        $document_types = $this->utility->getDocumentTypeDropDown();

        $users = $this->utility->getUserDropDown($business_id);
        //return $this->utility->getUserRoleName(Auth::user()->id);

        return view('accounting::transactions.index',compact('business_locations','vendors','document_types','users'));
     }

     public function getData(Request $request)
     {   
 
         $business_id = $request->session()->get('user.business_id');
 
         if($request->ajax()){
 
         
             $transaction_data =  DoubleEntryTransaction::where('business_id',$business_id)
                                                                 ->with(['added_user','location','vendor','transactionDetails'])
                                                                //  ->whereNotIn('document_type',['COS'])
                                                                 ->select('acc_transactions.*');
            if ($request->has('location_id')) {
               $location_id = request()->get('location_id');
               if (!empty($location_id)) {
                   $transaction_data->where('location_id', $location_id);
               }
             }

             if ($request->has('document_type')) {
                $document_type = request()->get('document_type');
                if (!empty($document_type)) {
                    $transaction_data->where('document_type', $document_type);
                }
              }

             if ($request->has('vendor_id')) {
                $vendor_id = request()->get('vendor_id');
                if (!empty($vendor_id)) {
                    $transaction_data->where('vendor_id', $vendor_id);
                }
              }

              if ($request->has('user_id')) {
                $user_id = request()->get('user_id');
                if (!empty($user_id)) {
                    $transaction_data->where('added_by', $user_id);
                }
              }

              

              if (!empty($request->start_date) && !empty($request->end_date)) {
                $start = request()->start_date;
                $end =  request()->end_date;
                $transaction_data->whereDate('transaction_date', '>=', $start)
                            ->whereDate('transaction_date', '<=', $end);
              }
             
             return Datatables::of($transaction_data)
                             ->addColumn('action',  function ($row) {
                                $html = '<div class="btn-group">
                                            <button type="button" class="btn btn-info dropdown-toggle btn-xs" 
                                                data-toggle="dropdown" aria-expanded="false">' .
                                                __("messages.actions") .
                                                '<span class="caret"></span><span class="sr-only">Toggle Dropdown
                                                </span>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-left" role="menu">' ;
        
                                $html .= '<li><a href="#"  class="btn-modal" data-container=".view_modal"><i class="fas fa-eye" aria-hidden="true"></i> ' . 'View' . '</a></li>';
                                
                                if($row->document_type==config('accounting.document_type_prefix.cheque_payment_vc')){
                                    $html .= '<li><a target="_blank" href="'.action("\Modules\Accounting\Http\Controllers\DoubleEntryAccountDocumentController@printPaymentVoucher", [$row->id]).'" 
                                          class="btn-modsal"><i class="fas fa-print" aria-hidden="true"></i> ' . 'Print Voucher' . '</a></li>';
                                    if($row->is_print_chq==0){
                                        $html .= '<li><a class="cheque-print" target="_blank" href="'.action("\Modules\Accounting\Http\Controllers\DoubleEntryAccountDocumentController@printCheque", [$row->id]).'" 
                                          class="btn-modals" ><i class="fas fa-money-bill-alt" aria-hidden="true"></i> ' . 'Print Cheque' . '</a></li>';
                                    }else{
                                        if($this->utility->getUserRoleName(Auth::user()->id)=='Admin')   {
                                            $html .= '<li><a class="cheque-print" target="_blank" href="'.action("\Modules\Accounting\Http\Controllers\DoubleEntryAccountDocumentController@printCheque", [$row->id]).'" 
                                            class="btn-modasl" ><i class="fas fa-undo" aria-hidden="true"></i> ' . 'Restore Cheque Print' . '</a></li>';
                                        }
                                    }
                                }
                                  
        
                                $html .= '</ul></div>';
        
                                return $html;
                            })
                            ->editColumn(
                                'payment_note',
                                function ($row) {
                                     $desc='';
                                     if(isset($row->vendor)){
                                        if($row->vendor->type=='supplier' || $row->vendor->type=='both'){
                                            $desc=$row->vendor->supplier_business_name;
                                        }else{
                                            $desc=$row->vendor->name; 
                                        }

                                        return $desc.=' - '.$this->accountUtility->mapDocumentType($row->document_type,$row,$row->transactionDetails); 
                                     }

                                     return $this->accountUtility->mapDocumentType($row->document_type,$row,$row->transactionDetails);                                    
                                }
                            )
                             ->editColumn('transaction_date', '{{@format_datetime($transaction_date)}}')
                             ->editColumn(
                                'payment_status_info',
                                function ($row) {
                                    $payment_status='';

                                    if(isset($row->payment_status)){
                                        if($row->payment_status=='due'){
                                            $payment_status ='<span class="label bg-yellow">DUE</span>';
                                            return $payment_status;
                                        }else if($row->payment_status=='patial'){
                                            $payment_status ='<span class="label bg-light-blue">PARTIAL</span>';
                                            return $payment_status;
                                        }else{
                                            $payment_status ='<span class="label bg-green">PAID</span>';
                                            return $payment_status;
                                        }
                                    }                                   

                                    return null;

                                    
                                }
                            )
                            ->editColumn(
                                'total_amount',
                                function ($row) {
                                     return number_format($row->total_amount,2,'.',',');
                                }
                            )
                            ->editColumn(
                                'total_unaj_amount',
                                function ($row) {
                                     return number_format($row->total_unaj_amount,2,'.',',');
                                }
                            )
                             ->addColumn('status', function ($row) {  
                                $is_canceled='';
                                if(isset($row->is_canceled)){
                                    if($row->is_canceled==0){
                                        $is_canceled ='<span class="label bg-green">DONE</span>';
                                        return $is_canceled;
                                    }else {
                                        $is_canceled ='<span class="label bg-danger">CANCELED</span>';
                                        return $is_canceled;
                                    }
                                } 
                                 
                             })
                             ->rawColumns(['action','status','payment_status_info','payment_note','cheque_no'])
                             ->make(true);
 
         }
         return null;
     }
}
