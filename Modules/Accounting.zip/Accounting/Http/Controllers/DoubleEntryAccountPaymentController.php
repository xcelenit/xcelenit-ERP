<?php

namespace Modules\Accounting\Http\Controllers;

use App\BusinessLocation;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Utils\TransactionUtil;
use Illuminate\Routing\Controller;
use Modules\Accounting\Entities\Utility\Utility;
use Modules\Accounting\Entities\DoubleEntryAccount;
use Modules\Accounting\Entities\Utility\AccountUtility;
use Modules\Accounting\Entities\Utility\AccountTransactionUtility;

class DoubleEntryAccountPaymentController extends Controller
{   

    protected $accountUtility;
    protected $utility;
    protected $accountTransactionutility;
    protected $transactionUtil;


    public function __construct(Utility $utility, AccountUtility $accountUtility,TransactionUtil $transactionUtil,AccountTransactionUtility $accountTransactionutility) {
        $this->utility = $utility;
        $this->accountUtility = $accountUtility;
        $this->transactionUtil = $transactionUtil;
        $this->accountTransactionutility = $accountTransactionutility;

    }  
    
    public function addReceipt()
    {   
        $business_id = request()->session()->get('user.business_id');  
        $doc_type_code = config('accounting.document_type_prefix.receipt');
        $doc_type = $this->accountUtility->getDocumentTypeByCode($doc_type_code);
        $contact_dropdown = $this->utility->DebitorDropdown($business_id, false, false);
         
        $payment_method_array = collect(config('accounting.payment_methods'));
        // $payment_method_array=[];
        // $payment_method_array = $payment_methods->pluck('name','default_account_id');

        $debit_account_list = DoubleEntryAccount::getReceiptDebitAccountList();

        $locations = BusinessLocation::where('business_id',$business_id)->pluck('name','id');
        $locations = $locations->prepend('None', '');

        //return $debit_account_list;

        $current_fy_period = $this->accountTransactionutility->getCurrentFinancialYear($business_id, date('Y-m-d'));
        
        return view('accounting::payments.add_receipt', compact('doc_type','contact_dropdown','payment_method_array','current_fy_period','debit_account_list','locations'));
    }

    public function addPettyCashVoucher()
    {   
        $business_id = request()->session()->get('user.business_id');  
        $doc_type_code = config('accounting.document_type_prefix.petty_cash_vc');
        $doc_type = $this->accountUtility->getDocumentTypeByCode($doc_type_code);
        $contact_dropdown = $this->utility->CreditorDropdown($business_id, false, false);
         
        $payment_method_array = collect(config('accounting.payment_methods'));
        $payment_method_array = $payment_method_array->where('method','cash');

        $credit_account_list = DoubleEntryAccount::getPettyCashAccountList();

        $locations = BusinessLocation::where('business_id',$business_id)->pluck('name','id');
        $locations = $locations->prepend('None', '');

        
        $current_fy_period = $this->accountTransactionutility->getCurrentFinancialYear($business_id, date('Y-m-d'));
        
        return view('accounting::payments.add_payment_voucher', compact('doc_type','contact_dropdown','payment_method_array','current_fy_period','credit_account_list','locations'));
    }

    public function addChequeVoucher()
    {
        $business_id = request()->session()->get('user.business_id');  
        $doc_type_code = config('accounting.document_type_prefix.cheque_payment_vc');
        $doc_type = $this->accountUtility->getDocumentTypeByCode($doc_type_code);
        $contact_dropdown = $this->utility->CreditorDropdown($business_id, false, false);
         
        $payment_method_array = collect(config('accounting.payment_methods'));
        $payment_method_array = $payment_method_array->where('method','cheque');

        $credit_account_list = DoubleEntryAccount::getBankAccountList();

        $locations = BusinessLocation::where('business_id',$business_id)->pluck('name','id');
        $locations = $locations->prepend('None', '');

        $locations = BusinessLocation::where('business_id',$business_id)->pluck('name','id');
        $locations = $locations->prepend('None', '');

               
        $current_fy_period = $this->accountTransactionutility->getCurrentFinancialYear($business_id, date('Y-m-d'));
        
        return view('accounting::payments.add_payment_voucher', compact('doc_type','contact_dropdown','payment_method_array','current_fy_period','credit_account_list','locations'));
    }

    public function getPyeeByVendor(Request $request)
    {
        $payees = $this->utility->CreditorPayeeDropdown($request->vendor_id);
        $htlm='';
        if(isset($payees)){
            foreach($payees as $payee){
                $htlm.='<option value="'.$payee.'">'.$payee.'</option>';
            }
        }
        return $htlm;
    }

    public function getDebtorDueInvoice(Request $request)
    {   
        $business_id = $request->session()->get('user.business_id');
        $Invoice_List =  $this->accountUtility->getUnpaidDebtorInvoice($business_id,$request->vendor_id);

        //return $Invoice_List;

        $html='';

        foreach($Invoice_List as $row){

            $due_amount = ($row->total_amount - (isset($row->total_paid) ? $row->total_paid : '0.00'));
            
            $ref_no = $row->transactionDetails[0]->ref_no;

                         
            $payment_status ='';
            
            if($row->payment_status=='due'){
                $payment_status ='<span class="label bg-yellow">'.strtoupper($row->payment_status).'</span>';
            }else{
                $payment_status ='<span class="label bg-light-blue">'.strtoupper($row->payment_status).'</span>';
            }

            $html.='<tr class="text-center">                    
                    <td>'.$row->transaction_date.'</td>
                    <td>'.$row->document_no.' ('.$ref_no.')</td>
                    <td class="text-center">'.(isset($row->location->name) ? $row->location->name : '').'</td>
                    <td class="text-center">'.$payment_status.'</td>
                    <td class="text-right">'.(number_format($row->total_amount,2,'.',',')).'</td>
                    <td class="text-right">'.(isset($row->total_paid) ? number_format($row->total_paid,2,'.',',') : '0.00').'</td>
                    <td class="text-right">'.(number_format($due_amount,2,'.',',')).'</td>
                    <td><input type="checkbox" class="transaction_id" value="'.$row->id.'" ></td>
                    <td class="text-center">
                    <input type="hidden" class="form-control text-right ref_no" value="'.$ref_no.'">
                    <input type="hidden" class="form-control text-right balance_amount" value="'.$due_amount.'">
                    <input type="number" class="form-control text-right adjusted" disabled value="0.00">
                    </td>
                    </tr>';
        }

        return $html;

    }
       
    public function getCreditorDueInvoice(Request $request)
    {   
        $business_id = $request->session()->get('user.business_id');
        $Invoice_List =  $this->accountUtility->getUnpaidCreditorInvoice($business_id, $request->vendor_id);

        //return $Invoice_List;

        $html='';

        foreach($Invoice_List as $row){

            $due_amount = ($row->total_amount - (isset($row->total_paid) ? $row->total_paid : '0.00'));
            
            $ref_no = $row->transactionDetails[0]->ref_no;
            $desc = $row->transactionDetails[0]->desc;
                         
            $payment_status ='';
            
            if($row->payment_status=='due'){
                $payment_status ='<span class="label bg-yellow">'.strtoupper($row->payment_status).'</span>';
            }else{
                $payment_status ='<span class="label bg-light-blue">'.strtoupper($row->payment_status).'</span>';
            }

            $html.='<tr class="text-center">                    
                    <td>'.$row->transaction_date.'</td>
                    <td>'.$row->document_no.' ('.$ref_no.')</td>
                    <td class="text-center">'.(isset($row->location->name) ? $row->location->name : '').'</td>
                    <td class="text-center">'.$payment_status.'</td>
                    <td class="text-right">'.(number_format($row->total_amount,2,'.',',')).'</td>
                    <td class="text-right">'.(isset($row->total_paid) ? number_format($row->total_paid,2,'.',',') : '0.00').'</td>
                    <td class="text-right">'.(number_format($due_amount,2,'.',',')).'</td>
                    <td><input type="checkbox" class="transaction_id" value="'.$row->id.'" ></td>
                    <td class="text-center">
                    <input type="hidden" class="form-control text-right ref_no" value="'.$ref_no.'">
                    <input type="hidden" class="form-control text-right desc" value="'.$desc.'">

                    <input type="hidden" class="form-control text-right balance_amount" value="'.$due_amount.'">
                    <input type="number" class="form-control text-right adjusted" disabled value="0.00">
                    </td>
                    </tr>';
        }

        $payees = $this->utility->CreditorPayeeDropdown($request->vendor_id);
        $payee_htlm='';
        if(isset($payees)){
            foreach($payees as $payee){
                $payee_htlm.='<option value="'.$payee.'">'.$payee.'</option>';
            }
        }

        return ['inv'=>$html,'payee'=>$payee_htlm];

         

    }
    
    public function storeDebtorPayment(Request $request)
    {
      

       // return $request->all();
        $business_id = $request->session()->get('user.business_id');
        $reference_lines= [];
        $details_list =  $request->details_list;
        if(isset($details_list)>0){
            foreach($details_list as $item){
                 
                $reference_lines[]= [
                                'perent_transaction_id'=>$item['perent_transaction_id'],
                                'ref_no'=>$item['ref_no'],
                                'sub_amount'=>$item['sub_amount'],
                                'desc'=>$item['desc']
                            ];
            }
        } 

        $payment = [
            'location_id' =>isset($request->location_id) ? $request->location_id : null,
            'contact_id' => $request->vendor_id,
            'transaction_date' => date("Y-m-d H:i:s",strtotime($request->transaction_date)),
            'payment_method' => strtolower($request->payment_method),
            'payment_note' => $request->payment_note,
            'cheque_date' => isset($request->cheque_date) ? date("Y-m-d", strtotime($request->cheque_date)) : null,
            'cheque_no' => $request->cheque_no,
            'total_amount' => $request->amount
        ];
      // return $payment;
       
      $this->accountTransactionutility->createReceipt($business_id, $payment['location_id'], $request->vendor_id, $payment, $reference_lines);

       return 'done';

    }

    public function storeCreditorPayment(Request $request)
    {   
       // return $request->all();
        $business_id = $request->session()->get('user.business_id');       
        $reference_lines= [];
        $details_list =  $request->details_list;
        if(isset($details_list)>0){
            foreach($details_list as $item){
                 
                $reference_lines[]= [
                                'perent_transaction_id'=>$item['perent_transaction_id'],
                                'ref_no'=>$item['ref_no'],
                                'sub_amount'=>$item['sub_amount'],
                                'desc'=>$item['desc']
                            ];
            }
        }

        // $payment['location_id'] = isset($request->location_id) ? $request->location_id : null;
        // $payment['contact_id'] =$request->vendor_id;
        // $payment['transaction_date'] = date("Y-m-d H:i:s",strtotime($request->transaction_date));
        // $payment['total_amount'] = $request->amount;
        // $payment['payment_method'] = strtolower($request->payment_method);
        // $payment['payment_note'] = $request->payment_note;
        // $payment['credit_account_id'] = $request->account_id;       

        // $payment['cheque_date'] = date("Y-m-d",strtotime($request->cheque_date));
        // $payment['cheque_no'] = $request->cheque_no;

        // $payment['document_type'] = $request->document_type;


        $payment = [
            'location_id' =>isset($request->location_id) ? $request->location_id : null,
            'contact_id' => $request->vendor_id,
            'transaction_date' => date("Y-m-d H:i:s",strtotime($request->transaction_date)),
            'payment_method' => strtolower($request->payment_method),
            'payment_note' => $request->payment_note,
            'cheque_date' => isset($request->cheque_date) ? date("Y-m-d", strtotime($request->cheque_date)) : null,
            'cheque_no' => $request->cheque_no,
            'total_amount' => $request->amount,
            'credit_account_id' =>$request->account_id,
            'document_type' => $request->document_type,
            'payee' => isset($request->payee) ? $request->payee : null,
        ];

       
        $this->accountTransactionutility->createCreditorVoucher($business_id,$payment['location_id'], $request->vendor_id, $payment,$reference_lines);

       return 'done';
    }
    
    


}
