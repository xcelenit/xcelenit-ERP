<?php

namespace Modules\Accounting\Entities;

use Illuminate\Database\Eloquent\Model;
use Modules\Accounting\Entities\DoubleEntryAccount;

class DoubleEntryAccountType extends Model
{
    protected $fillable = ['type_code','type','trs_type'];
    protected $table='acc_account_types';

    public function accounts()
    {
        return $this->hasMany(DoubleEntryAccount::class, 'account_type_id');
    }

    public function category()
    {
        return $this->hasMany(DoubleEntryAccountCategory::class, 'account_type_id');
    }

    public static function getDropDown()
    {
        return DoubleEntryAccountType::pluck('type', 'id');
    }


}
