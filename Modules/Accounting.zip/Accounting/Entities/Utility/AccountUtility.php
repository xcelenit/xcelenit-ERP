<?php

namespace Modules\Accounting\Entities\Utility;

use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;
use Modules\Accounting\Entities\DoubleEntryAccount;
use Modules\Accounting\Entities\DoubleEntryTransaction;
use Modules\Accounting\Entities\DoubleEntryLedgerTransaction;

class AccountUtility extends Model
{
     //Get Account Transaction
     public function getControlAccountTransaction($business_id,$type, $contact_id, $start_date, $end_date)
     {
         
         if($type == 'debtor'){
            $account_id = config('accounting.default_account_ids.debtor');
        }else{
            $account_id = config('accounting.default_account_ids.creditor'); 
        }
        
         return  $this->getLedgerTransaction($business_id,$account_id, $contact_id, $start_date, $end_date);
                 
     }

     public function getLedgerAccountTransaction($business_id, $account_id, $start_date, $end_date)
     {
         
         return  $this->getLedgerTransaction($business_id, $account_id, $contact_id, $start_date, $end_date);
                 
     }



     public function getLedgerTransaction($business_id, $account_id , $contact_id, $start_date, $end_date)
     {
                $ledger_transactions = DoubleEntryLedgerTransaction::join('acc_accounts AS A','A.id','=','acc_ledger_transactions.account_id')
                    ->join('acc_transactions as AT','AT.id','=','acc_ledger_transactions.transaction_id')
                    ->with(['transactionDetails'])
                    ->where('A.id',$account_id)
                    ->where('AT.business_id',$business_id);

                    if(isset($contact_id)){
                        $ledger_transactions->where('AT.vendor_id',$contact_id);
                    }                      

                    $ledger_transactions->where('AT.is_canceled',0)
                    ->whereBetween(DB::raw('date(AT.transaction_date)'), [$start_date, $end_date])
                    ->select(['acc_ledger_transactions.*','AT.added_by','AT.vendor_id','AT.document_no','AT.document_type','AT.transaction_date','AT.payment_method','A.account_type_id as ac_type',
                    
                        DB::raw('(SELECT SUM(IF(ALE.entry_type=IF((ac_type <= 2), "DR", "CR"), ALE.amount, -1 * ALE.amount)) FROM acc_ledger_transactions AS ALE 
                                INNER JOIN acc_transactions AS ATS ON ALE.transaction_id = ATS.id WHERE ATS.transaction_date <= AT.transaction_date AND ALE.account_id = acc_ledger_transactions.account_id 
                                AND ATS.is_canceled=0 AND ALE.id <= acc_ledger_transactions.id) as balance')
                        ])                        //IF(A.account_type_id >= 3,"CR","DR")
                    ->groupBy('acc_ledger_transactions.id')                    
                    ->orderBy('AT.transaction_date', 'ASC')
                    ->orderBy('acc_ledger_transactions.id', 'ASC')
                    ->get();
                 
        return $ledger_transactions;
     }

     public function getAccountSummary($account_id, $contact_id=null)
     {
         $account = DoubleEntryAccount::find($account_id);  

         return $account->getSummary($contact_id);
     }

     public function mapDocumentType($document_type, $transaction, $transactionDetails)
     {
         $document_type_array = collect(config('accounting.document_type'));         
         $filtered = $document_type_array->where('code', $document_type)->first();
         $str='';
         if(isset($filtered)){

            

            if($transaction->payment_method!=null){

               // $str.=strtoupper($transaction->payment_method).' '.$filtered['type'];
                if($filtered['code']=='RCP'){
                    $str.=strtoupper($transaction->payment_method).' '.$filtered['type'];
                }else{
                    $str.=$filtered['type'];
                }
               

                
                if($transaction->cheque_no!=null){
                    $str.=' ( Cheque No : '.$transaction->cheque_no;
                    if($transaction->payee!=null){
                        $str.=' | Payee : '.$transaction->payee;
                    }
                    $str.=' )';
                }

                if($transaction->payment_note!=null){
                    $str.=' Payment Note: <small>'.$transaction->payment_note.'</small> :';
                }                
            }else{
                $str=$filtered['type'].' : ';
            }

            $count=0;
            foreach($transactionDetails as $transDetail){
                $count++;
                $str .='<span class="text-info"> <a href="#">'.$transDetail->ref_no.'</a></span>';
                if(count($transactionDetails) > $count){
                    $str .=',';
                }
            }

            

            return $str;

         }else{
            
            // if($transaction->payment_note!=null){
            //     $str.=' Payment Note: <small>'.$transaction->payment_note.'</small> :';
            // }  

            //  if(count($transactionDetails)>0){
            //     $count=0;
                 
            //     foreach($transactionDetails as $transDetail){
            //         $count++;
            //         $str .='<span class="text-info"> <a href="#">'.$transDetail->ref_no.'</a></span>';
            //         if(count($transactionDetails) > $count){
            //             $str .=',';
            //         }
            //     }
            //     return $str;
            //  }
            

             return null;
         }
         
        
     }

     public function getDocumentTypeByCode($code)
     {
        $document_type_array = collect(config('accounting.document_type'));         
        $filtered = $document_type_array->where('code', $code)->first();

        return $filtered;
     }

     

     public function getUnpaidDebtorInvoice($business_id, $vendor_id)
     {  
         
         $sales_invoices = DoubleEntryTransaction::with(['transactionDetails'])
                                                 ->with(['location'=> function($queary){
                                                    $queary->select('id','name');
                                                 }])
                                                 ->where('acc_transactions.vendor_id',$vendor_id)
                                                 ->where('acc_transactions.document_type',config('accounting.document_type_prefix.sales'))                                                 
                                                 ->where('acc_transactions.is_canceled', 0)  
                                                 ->whereIn('acc_transactions.payment_status', ['due','patial'])                                               
                                                 ->select('acc_transactions.id','acc_transactions.location_id','acc_transactions.document_no','acc_transactions.transaction_date','acc_transactions.payment_status','acc_transactions.total_amount',
                                                    
                                                 DB::raw('(SELECT SUM(ATD.sub_amount) FROM acc_transactions AS RC 
                                                             INNER JOIN acc_transaction_details AS ATD 
                                                             ON RC.id = ATD.transaction_id 
                                                             WHERE RC.document_type="RCP" AND RC.is_canceled="0" AND ATD.perent_transaction_id = acc_transactions.id ) AS total_paid')
                                                 )
                                                 ->get();

            return $sales_invoices;
     }

     public function getUnpaidCreditorInvoice($business_id, $vendor_id)
     {  
         
         $sales_invoices = DoubleEntryTransaction::with(['transactionDetails'])
                                                 ->with(['location'=> function($queary){
                                                    $queary->select('id','name');
                                                 }])
                                                 ->where('acc_transactions.vendor_id',$vendor_id)
                                                 ->whereIn('acc_transactions.document_type',[
                                                     config('accounting.document_type_prefix.grn'),
                                                     config('accounting.document_type_prefix.expenses')])                                                 
                                                 ->where('acc_transactions.is_canceled', 0)  
                                                 ->whereIn('acc_transactions.payment_status', ['due','patial'])                                               
                                                 ->select('acc_transactions.id','acc_transactions.location_id','acc_transactions.document_no','acc_transactions.transaction_date','acc_transactions.payment_status','acc_transactions.total_amount',
                                                    
                                                 DB::raw('(SELECT SUM(ATD.sub_amount) FROM acc_transactions AS VC
                                                             INNER JOIN acc_transaction_details AS ATD 
                                                             ON VC.id = ATD.transaction_id 
                                                             WHERE VC.document_type IN ("PCV","CPV","BCA") AND VC.is_canceled="0" AND ATD.perent_transaction_id = acc_transactions.id ) AS total_paid')
                                                 )
                                                 ->get();

            return $sales_invoices;
     }

     
}

/*
leager account name      debit   credit  
asset
    non current asset
        propert
    