<?php

namespace Modules\Accounting\Entities\Utility;

use App\User;
use App\Contact;
use App\Utils\Util;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;
use Modules\Accounting\Entities\DoubleEntryAccount;

class Utility extends Util
{

    
    public static function DebitorDropdown($business_id, $prepend_none = true, $append_id = true)
    {
        $all_contacts = Contact::where('business_id', $business_id)
                        ->whereIn('type', ['customer', 'both']);
                        //->active();

        if ($append_id) {
            $all_contacts->select(
                DB::raw("IF(contact_id IS NULL OR contact_id='', name, CONCAT(name, ' (', contact_id, ')')) AS customer"),
                'id'
                );
        } else {
            $all_contacts->select('id', DB::raw("name as customer"));
        }

        if (!auth()->user()->can('customer.view') && auth()->user()->can('customer.view_own')) {
            $all_contacts->where('contacts.created_by', auth()->user()->id);
        }

        $customers = $all_contacts->pluck('customer', 'id');

        //Prepend none
        if ($prepend_none) {
            $customers = $customers->prepend(__('lang_v1.none'), '');
        }

        return $customers;
    }

    public static function CreditorDropdown($business_id, $prepend_none = true, $append_id = true)
    {
        $all_contacts = Contact::where('business_id', $business_id)
                        ->whereIn('type', ['supplier', 'both']);
                        //->active();

        if ($append_id) {
            $all_contacts->select(
                DB::raw("IF(contact_id IS NULL OR contact_id='', name, CONCAT(name, ' (', contact_id, ')')) AS customer"),
                'id'
                );
        } else {
            $all_contacts->select('id', DB::raw("name as customer"));
        }

        if (!auth()->user()->can('customer.view') && auth()->user()->can('customer.view_own')) {
            $all_contacts->where('contacts.created_by', auth()->user()->id);
        }

        $customers = $all_contacts->pluck('customer', 'id');

        //Prepend none
        if ($prepend_none) {
            $customers = $customers->prepend(__('lang_v1.none'), '');
        }

        return $customers;
    }

    public static function vendorDropdown($business_id, $prepend_none = true, $append_id = true)
    {
        $all_contacts = Contact::where('business_id', $business_id)
                        ->whereIn('type', ['supplier','customer', 'both']);
                        //->active();

        if ($append_id) {
            $all_contacts->select(
                DB::raw("IF(contact_id IS NULL OR contact_id='', name, CONCAT(name, ' (', contact_id, ')')) AS customer"),
                'id'
                );
        } else {
            $all_contacts->select('id', DB::raw("name as customer"));
        }

        // if (!auth()->user()->can('customer.view') && auth()->user()->can('customer.view_own')) {
        //     $all_contacts->where('contacts.created_by', auth()->user()->id);
        // }

        $customers = $all_contacts->pluck('customer', 'id');

        //Prepend none
        if ($prepend_none) {
            $customers = $customers->prepend('All', '');
        }

        return $customers;
    }

    public static function CreditorPayeeDropdown($vendor_id)
    {
        
        $contact = Contact::where('id', $vendor_id)
                        ->whereIn('type', ['supplier', 'both'])
                        ->select('id', 'name','supplier_business_name','custom_field1','custom_field2','custom_field3')->first();
        
        $payee_list =[];

        if($contact->supplier_business_name!=null){
            $payee_list[] = $contact->supplier_business_name;
        }

        if($contact->name!=null){
            $payee_list[] = $contact->name;
        }
        if($contact->custom_field1!=null){
            $payee_list[] = $contact->custom_field1;
        }
        if($contact->custom_field2!=null){
            $payee_list[] = $contact->custom_field2;
        }

        if($contact->custom_field3!=null){
            $payee_list[] = $contact->custom_field3;
        }
                
        $payee_list[] = 'CASH';
        
        

        return $payee_list;
    }

    public function getDocumentTypeDropDown()
    {
       $document_type_array = collect(config('accounting.document_type'));         
       $list = $document_type_array->pluck('type','code');

       $list = $list->prepend('All', '');
       
       return $list;
    }

    public function getUserDropDown($business_id)
    {
       $users_data = User::where('business_id',$business_id)
       ->where('allow_login',1);
       
       if(Auth::user()->id != 1){
           $users_data->whereNotIn('id',[1]);
       }                        
       
       $users =  $users_data->where('status','active')
               ->where('user_type','user')->pluck('username','id'); 

       $users = $users->prepend('All', '');
       return $users;
       

    }

    public function getBankAccountsWithBalance($business_id)
    {
        $bank_accounts = DoubleEntryAccount::where('business_id',$business_id)
                                            ->where('is_bank_ac',1)
                                            ->where('is_active',1)
                                            ->select('account_name','account_no','balance')
                                            ->where('account_type_id',1)->orderBy('account_code','ASC')->get();
        return $bank_accounts;
    }

    public function getInHandAccountsWithBalance($business_id)
    {
        $bank_accounts = DoubleEntryAccount::where('business_id',$business_id)
                                            ->whereIn('id',config('accounting.default_in_hand_account_ids'))
                                            ->where('is_active',1)                                             
                                            ->select('account_name','account_no','balance')
                                            ->where('account_type_id',1)->orderBy('account_code','ASC')->get();
        return $bank_accounts;
    }
    
    public function getDashboardDataByDate($business_id, $start_date, $end_date)
    {
         $total_income = DoubleEntryAccount::where('business_id',$business_id)
                                            ->where('account_type_id',config('accounting.default_account_type.income'))->sum('balance');

        $total_expense =  $total_income = DoubleEntryAccount::where('business_id',$business_id)
                                            ->where('account_type_id',config('accounting.default_account_type.expenses'))->sum('balance');
        
    }

    
}
