<?php

namespace Modules\Accounting\Entities\Utility;

use App\Business;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Model;
use Modules\Accounting\Entities\DoubleEntryAccount;
use Modules\Accounting\Entities\DoubleEntryTransaction;
use Modules\Accounting\Entities\DoubleEntryTransactionDetail;
use Modules\Accounting\Entities\DoubleEntryTransactionSchemes;

class AccountTransactionUtility extends Model
{
    

    public function createSalesEntry($business_id, $transaction, $payments)
    {   
        //

        $reference_line=[];
        $reference_line['ref_no'] = $transaction['invoice_no'];
        $reference_line['desc'] = null;
        $reference_line['perent_transaction_id'] = null;
        $reference_line['sub_amount'] = null;

        
        $reference_lines[]= $reference_line;

       // return $reference_lines;

        $debit_account_id = config('accounting.default_account_ids.debtor');
        $credit_account_id = config('accounting.default_account_ids.sales');

       $Sale_transaction =  $this->CreateTransaction($business_id, 
                                        $transaction['location_id'],$transaction['contact_id'],$reference_lines, 'SAL', 
                                        $transaction['transaction_date'],$transaction['total_amount'],
                                        null,null,null,null,null, $debit_account_id, $credit_account_id, 1, 'due');
    
       if($Sale_transaction!='error'){
            $receipt_transaction='';
            $costOfSale_transaction='';
            if(isset($transaction['total_cost'])){
                 
                $costOfSale_transaction = $this->updateCosOfSale($business_id, $transaction['location_id'],$transaction,$reference_lines,$Sale_transaction->id);
                
            }            

            if(isset($payments)){
                foreach($payments as $payment){

                   $reference_lines= [];

                   $reference_line['perent_transaction_id'] = $Sale_transaction->id;
                   $reference_line['sub_amount'] = $payment['total_amount'];
                   $reference_lines[] = $reference_line;

                   $receipt_transaction = $this->createReceipt($business_id,$transaction['location_id'],$transaction['contact_id'],$payment, $reference_lines, $Sale_transaction->id);
                   if($receipt_transaction=='error'){
                       break;
                   }
                }
            }


            if($receipt_transaction!='error' && $receipt_transaction!='error'){
                return 'done';
            }else{
                $this->removeTransaction($Sale_transaction->id);
                return 'error';
            }

        
            
        }else{
            return 'error';
        }
        

    }
        
    public function createReceipt($business_id,$location_id,$contact_id, $payment, $reference_lines, $perent_transaction_id=null)
    {   
                
        
        $debit_account_id = null;

        
        
        $credit_account_id = config('accounting.default_account_ids.debtor');
        
        if(isset($payment['debit_account_id'])) {
            $debit_account_id = $payment['debit_account_id'];
        }else
        {   
            if($payment['payment_method']=='cash'){
                $debit_account_id = config('accounting.default_account_ids.cash_in_hand');                
            }else if($payment['payment_method']=='cheque'){
                $debit_account_id = config('accounting.default_account_ids.cheque_in_hand');                
            }else if($payment['payment_method']=='card'){
                $debit_account_id = config('accounting.default_account_ids.card_payment');                
            }else if($payment['payment_method']=='other'){
                $debit_account_id = config('accounting.default_account_ids.other_payment');                
            }
        }
                
        $Account_transaction =  $this->CreateTransaction($business_id, 
                                $location_id, $contact_id, $reference_lines, 'RCP', $payment['transaction_date'],$payment['total_amount'],
                                isset($payment['payment_method']) ? $payment['payment_method'] : null,
                                isset($payment['cheque_no']) ? $payment['cheque_no'] : null,
                                isset($payment['payee']) ? $payment['payee'] : null,
                                isset($payment['cheque_date']) ? $payment['cheque_date'] : null,
                                isset($payment['payment_note']) ? $payment['payment_note'] : null,
                                $debit_account_id, $credit_account_id, 1, null , $perent_transaction_id);
        
        //Udpate Unadjusted
        if($Account_transaction!='error'){
            $this->updateUnAdjustedAmount($Account_transaction->id);
        }        

        foreach($reference_lines as $reference_line ){
            $this->updateDebtorPaymentStatus($reference_line['perent_transaction_id']);
        }
        

        return  $Account_transaction;
    }

    public function createPurchaseEntry($business_id, $transaction)
    {
        $reference_line=[];
        $reference_line['ref_no'] = $transaction['purchase_ref'];
        $reference_line['desc'] = isset($transaction['supplier_invoice_no']) ? $transaction['supplier_invoice_no'] : null;
        $reference_line['perent_transaction_id'] = null;
        $reference_line['sub_amount'] = null;
        $reference_lines[]= $reference_line;

        $debit_account_id = config('accounting.default_account_ids.inventory');
        $credit_account_id = config('accounting.default_account_ids.creditor');
        
        $Purchase_transaction =  $this->CreateTransaction($business_id, 
                                        $transaction['location_id'],$transaction['contact_id'],$reference_lines, 'GRN', 
                                        $transaction['transaction_date'],$transaction['total_amount'],
                                        null,null,null,null,null, $debit_account_id, $credit_account_id, 1, 'due');
        
        return $Purchase_transaction ;
    }

    public function createCreditorVoucher($business_id,$location_id,$contact_id,$payment, $reference_lines, $perent_transaction_id=null)
    {
        $cheque_no = null;
        $credit_account_id = null;

        $debit_account_id = config('accounting.default_account_ids.creditor');

        if(isset($payment['credit_account_id'])) {
            $credit_account_id = $payment['credit_account_id'];
            
            $Account_transaction =  $this->CreateTransaction($business_id, 
                                $location_id, $contact_id, $reference_lines, $payment['document_type'], $payment['transaction_date'],$payment['total_amount'],
                                isset($payment['payment_method']) ? $payment['payment_method'] : null,
                                isset($payment['cheque_no']) ? $payment['cheque_no'] : null,
                                isset($payment['payee']) ? $payment['payee'] : null,
                                isset($payment['cheque_date']) ? $payment['cheque_date'] : null,
                                isset($payment['payment_note']) ? $payment['payment_note'] : null,
                                $debit_account_id, $credit_account_id, 1, null , $perent_transaction_id);

          //Udpate Unadjusted
        if($Account_transaction!='error'){
            $this->updateUnAdjustedAmount($Account_transaction->id);
        }       
        
        foreach($reference_lines as $reference_line ){
            $this->updateCreditorPaymentStatus($reference_line['perent_transaction_id']);
        }                     

         return  $Account_transaction;
        }

        

    }

    public function updateDebtorPaymentStatus($perent_transaction_id)
    {
         $transaction = DoubleEntryTransaction::find($perent_transaction_id);

        
         $total_paid = 0;

         if($transaction->payment_status == 'patial'){
            $total_paid = DoubleEntryTransaction::join('acc_transaction_details AS ATD','ATD.transaction_id','=','acc_transactions.id')
                                                ->where('ATD.perent_transaction_id', $transaction->id)
                                                ->whereNotNull('acc_transactions.payment_method')
                                                ->whereIn('acc_transactions.document_type',[
                                                    config('accounting.document_type_prefix.receipt'),
                                                    config('accounting.document_type_prefix.petty_cash_vc'),
                                                    config('accounting.document_type_prefix.bank_debit_ad'),
                                                    config('accounting.document_type_prefix.bank_credit_ad'),
                                                    ])
                                                ->where('acc_transactions.is_canceled', 0)  
                                                ->sum('ATD.sub_amount');
                                                                              

         }

         if(isset($transaction)){
           
             if($transaction->total_amount  ==  ($total_paid)){
                
                $transaction->payment_status ='paid';
                $transaction->save();
               // return 'done';
             }else if($transaction->total_amount > ($total_paid)) {
                $transaction->payment_status ='patial';
                $transaction->save();
               // return 'done';
             }
         }

    }

    public function updateCreditorPaymentStatus($perent_transaction_id)
    {
         $transaction = DoubleEntryTransaction::find($perent_transaction_id);

         
         $total_paid = 0;

         if($transaction->payment_status == 'patial'){
            $total_paid = DoubleEntryTransaction::join('acc_transaction_details AS ATD','ATD.transaction_id','=','acc_transactions.id')
                                                ->where('ATD.perent_transaction_id', $transaction->id)
                                                ->whereNotNull('acc_transactions.payment_method')
                                                ->whereIn('acc_transactions.document_type',[
                                                    config('accounting.document_type_prefix.cheque_payment_vc'),
                                                    config('accounting.document_type_prefix.petty_cash_vc'),
                                                    // config('accounting.document_type_prefix.bank_debit_ad'),
                                                    config('accounting.document_type_prefix.bank_credit_ad'),
                                                    ])
                                                ->where('acc_transactions.is_canceled', 0)  
                                                ->sum('ATD.sub_amount');
                                                                              

         }

         if(isset($transaction)){
           
             if($transaction->total_amount  ==  ($total_paid)){
                
                $transaction->payment_status ='paid';
                $transaction->save();
               // return 'done';
             }else if($transaction->total_amount > ($total_paid)) {
                $transaction->payment_status ='patial';
                $transaction->save();
               // return 'done';
             }
         }

    }
    
    public function updateCosOfSale($business_id, $location_id,$transaction,$reference_line,$perent_transaction_id)
    {
        $credit_account_id = config('accounting.default_account_ids.inventory');
        $debit_account_id = config('accounting.default_account_ids.cost_of_sale');

        $Account_transaction =  $this->CreateTransaction($business_id, $location_id, null, $reference_line, 'COS', $transaction['transaction_date'], $transaction['total_cost'],
                                null,null,null,null,null, $debit_account_id, $credit_account_id, 1, null, $perent_transaction_id);

        return $Account_transaction;
    }

    public function CreateTransaction($business_id, $location_id, $vendor_id, $reference_line , $document_type, $transaction_date, 
                                    $total_amount, $payment_method, $cheque_no, $payee, $cheque_date, $payment_note, $debit_account_id, $credit_account_id,$status, $payment_status , $perent_transaction_id=null)
    {   
        try{    

            DB::beginTransaction();

            // Get Transaction Reffrence no           
            $reference_no = $this->getNewTransactionNoByType($business_id,$document_type);
            

            //Create new Transaction
            $newTransaction = new DoubleEntryTransaction();

            $newTransaction->business_id = $business_id;
            $newTransaction->location_id = $location_id;
            $newTransaction->added_by = Auth::user()->id;

            $newTransaction->vendor_id = $vendor_id;            
            $newTransaction->document_no = $reference_no;
            $newTransaction->document_type = $document_type;
            $newTransaction->transaction_date = $transaction_date;
            $newTransaction->payment_method = $payment_method;
            $newTransaction->total_amount = $total_amount;

            $newTransaction->cheque_no = $cheque_no;
            $newTransaction->payee = $payee;
            $newTransaction->cheque_date = $cheque_date;

            $newTransaction->payment_note = $payment_note;
            $newTransaction->perent_transaction_id = $perent_transaction_id;
            
            $newTransaction->period = $this->getCurrentFinancialYear($business_id, $transaction_date);

            if($payment_status!=null){
                $newTransaction->payment_status=$payment_status;
            }

            $newTransaction->is_rec = 0;
            $newTransaction->is_canceled =0;
            $newTransaction->is_print =0;
            $newTransaction->is_print_chq = 0;
            $newTransaction->status = $status;
            $newTransaction->save();
            

            //Create Ledger Entry (Debit/Credit entries)
            $newTransaction->ledgerTransactions()->createMany([
                ['account_id'=>$debit_account_id,'entry_type'=>'DR','amount'=>$total_amount],
                ['account_id'=>$credit_account_id,'entry_type'=>'CR','amount'=>$total_amount]
            ]);

            //Create Transaction Details
            if(count($reference_line)>0){
                $newTransaction->transactionDetails()->createMany($reference_line);
            }
            
            //Update Account Balances on CR and DR
            $this->updateBalanceOnTransaction($debit_account_id);
            $this->updateBalanceOnTransaction($credit_account_id);
            
            DB::commit();

            return $newTransaction;

        }catch(\Exception $e){
            DB::rollback();            
            Log::error($e);
            return 'error';
        }
        
        
    }

    public function removeTransaction($id)
    {   
        
        try{

            DB::beginTransaction();
            //Find Perent Transaction
            $transaction = DoubleEntryTransaction::find($id);
            //Find Child Transaction
            $child_transactions = DoubleEntryTransaction::where('perent_transaction_id',$id)->get();

            //Check has Child Transaction 
            if(isset($child_transactions)){
                
                //Remove Child Transactions
                foreach($child_transactions as $child_trans){
                    $child_trans->ledgerTransactions()->delete();
                    $child_trans->transactionDetails()->delete();
                    $child_trans->delete();
                }
            }

            //Remove Perent Transaction
            $transaction->ledgerTransactions()->delete();
            $transaction->transactionDetails()->delete();
            $transaction->delete();

            DB::commit();

            return 'done';

        }catch(\Exception $e){
            DB::rollback();            
            Log::error($e);
            return 'error';
        }

    }

    public function updateBalanceOnTransaction($account_id)
    {
         $account = DoubleEntryAccount::find($account_id);

         if(isset($account)){
            $account->balance = $account->getBalance();
            $account->save();

            return $account->balance;
         }

         return null;
         
    }

    public function updateUnAdjustedAmount($transaction_id)
    {
        $transaction = DoubleEntryTransaction::where('id',$transaction_id)
                     ->whereIn('document_type',[
                        config('accounting.document_type_prefix.receipt'),
                        config('accounting.document_type_prefix.petty_cash_vc'),
                        config('accounting.document_type_prefix.cheque_payment_vc'),
                        config('accounting.document_type_prefix.journal_vo'),
                        config('accounting.document_type_prefix.bank_debit_ad'),
                        config('accounting.document_type_prefix.bank_credit_ad'),
                        // config('accounting.document_type_prefix.bank_credit_ad'),
                     ])->first();
        $total_adjusted_amount = null;
        if(isset($transaction)){
            $total_adjusted_amount = $transaction->transactionDetails()->sum('sub_amount');
                        
            $total_unadjusted_amount = $transaction->total_amount - $total_adjusted_amount;             
            $transaction->total_unaj_amount = $total_unadjusted_amount;
            $transaction->save();            
        }
       
    }

    public function getNewTransactionNoByType($business_id,$document_type)
    {   
       
        $doc_no='';
        $current_year = date("Y");
        $schema = DoubleEntryTransactionSchemes::where('name',$document_type)->where('year',$current_year)->first();
        
        if(!isset($schema)){
            $desc = '';
            if($document_type=='PCV'){
                $schema_prefix = config('accounting.document_type_prefix.petty_cash_vc');
                $desc = 'Petty Cash Voucher';
            }else if($document_type=='CPV'){
                $schema_prefix = config('accounting.document_type_prefix.cheque_payment_vc');
                $desc = 'Cheque Payment Voucher';
            }else if($document_type=='BDA'){
                $schema_prefix = config('accounting.document_type_prefix.bank_debit_ad');
                $desc = 'Bank Debit Advisor';
            }else if($document_type=='BCA'){
                $schema_prefix = config('accounting.document_type_prefix.bank_credit_ad');
                $desc = 'Bank Credit Advisor';
            }else if($document_type=='JNV'){
                $schema_prefix = config('accounting.document_type_prefix.journal_vo');
                $desc = 'Journal Voucher';
            }else if($document_type=='SAL'){
                $schema_prefix = config('accounting.document_type_prefix.sales');
                $desc = 'Sales Invoice';
            }else if($document_type=='GRN'){
                $schema_prefix = config('accounting.document_type_prefix.grn');
                $desc = 'GRN';
            }else if($document_type=='EXP'){
                $schema_prefix = config('accounting.document_type_prefix.expenses');
                $desc = 'GRN';
            }else if($document_type=='RCP'){
                $schema_prefix = config('accounting.document_type_prefix.receipt');
                $desc = 'Receipt';
            }else if($document_type=='CRN'){
                $schema_prefix = config('accounting.document_type_prefix.cheque_return_note');
                $desc = 'Cheque Return Note';
            }else{
                return null;
            }

            $schema = new DoubleEntryTransactionSchemes();
            $schema->business_id = $business_id;
            $schema->name = $schema_prefix;
            $schema->desc = $desc;
            $schema->prefix = $schema_prefix;
            $schema->start_number = 0;
            $schema->count = 0;
            $schema->digit = 4;
            $schema->year = $current_year;
            $schema->save();            
        } 

        $schema->increment('count');
        $count_no = $schema->count;
        $num_ber = sprintf("%04d", ($count_no));

        $doc_no = $schema->prefix.$schema->year.'/'.$num_ber;
        return $doc_no;


    }

    public function getCurrentFinancialYear($business_id, $transaction_date)
    {
       $staring_month = Business::find($business_id);
       $staring_month = $staring_month->fy_start_month;
       $year = date("Y", strtotime($transaction_date));
       $month = date("m", strtotime($transaction_date));
        
       if($month < $staring_month){
        return $year-1;
       }else{
           return $year;
       }
    }

}
