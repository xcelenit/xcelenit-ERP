<?php

use Barryvdh\DomPDF\PDF;
use Illuminate\Support\Facades\App;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::group(['middleware' => ['web', 'authh', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu'], 'prefix' => 'accounting'], function () {
    
    //Dashboard
    Route::get('/', 'AccountingController@index');

    //Master Data
    Route::get('/master-data', 'AccountingController@masterData');
    Route::post('/master-data/store-account-types', 'DoubleEntryAccountCategoryController@store');    
    Route::get('/master-data/get-account-types', 'DoubleEntryAccountCategoryController@getData');

    //Accounts
    Route::get('/accounts', 'DoubleEntryAccountController@index');
    Route::get('/account/create', 'DoubleEntryAccountController@create');
    Route::post('/account/categories-by-type', 'DoubleEntryAccountCategoryController@getCategories');

    

    Route::post('/account/store', 'DoubleEntryAccountController@store');
    Route::get('/account/get', 'DoubleEntryAccountController@getData');

    Route::get('/control-accounts/{type}', 'AccountingController@controlACIndex');
    Route::post('/control-accounts/getdata', 'AccountingController@getControlACData');
    Route::post('/control-accounts/summary', 'AccountingController@getControlAccountSummary');


    //Receipt payment
    Route::get('/payment/receipt/add', 'DoubleEntryAccountPaymentController@addReceipt');
    Route::post('/payment/debtor/get-due-invoice', 'DoubleEntryAccountPaymentController@getDebtorDueInvoice');
    Route::post('/payment/debtor/store', 'DoubleEntryAccountPaymentController@storeDebtorPayment');

    //Add Payment Voucher
    Route::get('/payment/petty-cash-voucher/add', 'DoubleEntryAccountPaymentController@addPettyCashVoucher');
    Route::get('/payment/cheque-payment-voucher/add', 'DoubleEntryAccountPaymentController@addChequeVoucher');

    Route::post('/payment/creditor/get-due-invoice', 'DoubleEntryAccountPaymentController@getCreditorDueInvoice');
    Route::post('/payment/creditor/store', 'DoubleEntryAccountPaymentController@storeCreditorPayment');
    Route::post('/payment/get/creditor/payee', 'DoubleEntryAccountPaymentController@getPyeeByVendor');

    //transactions
    Route::get('/transactions', 'DoubleEntryAccountTransactionController@index');
    Route::post('/transactions/get', 'DoubleEntryAccountTransactionController@getData');


    //Reports
    Route::get('/report/trial-balance','DoubleEntryAccountReportController@trialBalance');
    Route::post('/report/trial-balance/data','DoubleEntryAccountReportController@trialBalanceData');


    //Printing Document
    Route::get('/documents/payment-voucher/{transaction_id}/print','DoubleEntryAccountDocumentController@printPaymentVoucher');
    Route::get('/documents/cheque/{transaction_id}/print','DoubleEntryAccountDocumentController@printCheque');


    //Ledger
    Route::get('/ledger','AccountingController@ledger');
    Route::post('/ledger/data','AccountingController@getledgerData');
    Route::post('/ledger/data/summary','AccountingController@getledgerSummary');

    //install
    Route::get('/install', 'InstallController@index');
    Route::post('/install', 'InstallController@install');
    Route::get('/install/uninstall', 'InstallController@uninstall');
    Route::get('/install/update', 'InstallController@update');


    

    Route::get('/pdf', function () {

        // $pdf = App::make('dompdf.wrapper');
        // $pdf->loadHTML('<h1>Test</h1>');
        // return $pdf->stream();
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadHTML('<h1>Test</h1>');
        $pdf->setPaper('a5', 'landscape');
        // $customPaper = array(0,0,360,360);
        // $pdf->set_paper($customPaper,'landscape');
        return $pdf->stream("dompdf_out.pdf",array("Attachment" => false));
         
    });
    

    

    



});