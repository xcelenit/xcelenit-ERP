<?php
 return [
"categories" => "Categorieën",
"manage_your_categories" => "Beheer uw categorieën",
"all_your_categories" => "Al uw categorieën",
"category" => "Categorie Code",
"category_name" => "Categorie naam",
"code" => "Code",
"add_as_sub_category" => "Toevoegen als subcategorie",
"select_parent_category" => "Selecteer bovenliggende categorie",
"added_success" => "Categorie succesvol toegevoegd",
"updated_success" => "Categorie succesvol bijgewerkt",
"deleted_success" => "Categorie succesvol verwijderd",
"add_category" => "Categorie toevoegen",
"edit_category" => "Categorie bewerken",
];
