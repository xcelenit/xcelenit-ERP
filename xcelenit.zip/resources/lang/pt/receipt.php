<?php
 return [
"product" => "Produto",
"qty" => "Quantidade",
"unit_price" => "preço unitário",
"subtotal" => "Subtotal",
"desconto" => "Desconto",
"tax" => "Taxa",
"total" => "Total",
"invoice_number" => "No. da fatura",
"date" => "Data",
"receipt_settings" => "Configurações de recibo",
"receipt_settings_mgs" => "Todas as configurações relacionadas a recibos para este local",
"print_receipt_on_invoice" => "Fatura de impressão automática após a conclusão",
"receipt_printer_type" => "Tipo de impressora de recibo",
"receipt_settings_updated" => "Ajuste de recebimento atualizado com sucesso",
];
