<?php
 return [
"categories" => "Categorias",
"manage_your_categories" => "Gerenciar suas categorias",
"all_your_categories" => "Todas as suas categorias",
"category" => "Categoría",
"category_name" => "Nome da categoria",
"code" => "Código de categoria",
"add_as_sub_category" => "Adicionar como subcategoria",
"select_parent_category" => "Selecionar categoria principal",
"added_success" => "Categoria adicionada com sucesso",
"updated_success" => "Categoria atualizada com sucesso",
"deleted_success" => "Categoria excluída com sucesso",
"add_category" => "Adicionar categoria",
"edit_category" => "Editar a categoria",
];
