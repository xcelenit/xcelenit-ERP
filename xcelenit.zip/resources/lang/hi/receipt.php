<?php
 return [
"product" => "उत्पाद",
"qty" => "मात्रा",
"unit_price" => "यूनिट मूल्य",
"subtotal" => "उप-योग",
"discount" => "छूट",
"tax" => "कर",
"total" => "कुल",
"invoice_number" => "चालान नंबर।",
"date" => "तारीख",
"receipt_settings" => "रसीद सेटिंग्स",
"receipt_settings_mgs" => "इस स्थान के लिए सभी रसीद संबंधित सेटिंग्स",
"print_receipt_on_invoice" => "अंतिम रूप देने के बाद ऑटो प्रिंट इनवॉइस",
"receipt_printer_type" => "रसीद प्रिंटर प्रकार",
"receipt_settings_updated" => "रसीद सेटअप सफलतापूर्वक अद्यतन किया गया",
];
