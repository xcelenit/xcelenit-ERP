<?php
 return [
"categories" => "Temat",
"manage_your_categories" => "Menaxhoni kategoritë tuaja",
"all_your_categories" => "Të gjitha kategoritë tuaja",
"category" => "Kategoria Kodi",
"category_name" => "Emri i kategorisë",
"code" => "Kodi",
"add_as_sub_category" => "Shto si nënkategori",
"select_parent_category" => "Zgjidh kategorinë mëmë",
"added_success" => "Kategoria u shtua me sukses",
"updated_success" => "Kategoria u përditësua me sukses",
"deleted_success" => "Kategoria u fshi me sukses",
"add_category" => "Shto kategorinë",
"edit_category" => "Modifiko kategorinë",
];
