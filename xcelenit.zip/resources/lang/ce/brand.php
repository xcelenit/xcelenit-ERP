<?php
 return [
"brands" => "Marken",
"manage_your_brands" => "Verwalten Sie Ihre Marken",
"all_your_brands" => "Alle deine Marken",
"note" => "Hinweis",
"brand_name" => "Markenname",
"short_description" => "Kurze Beschreibung",
"added_success" => "Marke hinzugefügt erfolgreich",
"updated_success" => "Marke wurde erfolgreich aktualisiert",
"deleted_success" => "Marke erfolgreich gelöscht",
"add_brand" => "Marke hinzufügen",
"edit_brand" => "Marke bearbeiten",
];
